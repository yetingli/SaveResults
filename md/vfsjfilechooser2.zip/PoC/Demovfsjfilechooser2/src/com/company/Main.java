package com.company;

import com.googlecode.vfsjfilechooser2.utils.VFSURIValidator;

public class Main {

    public static void main(String[] args) {
	// write your code here
        VFSURIValidator v = new VFSURIValidator();
        String _uri = "ftp://:@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::@::";
        System.out.println(v.isValid(_uri));
    }
}
